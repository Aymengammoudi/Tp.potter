package books;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * TODO : Add your import here
 */

public class BookShopTest {

    BookShopTest BookShopTest;

    @Before
    public void setup() {
        List<BooksSetDiscount> byDifferentCopiesDiscountList = new ArrayList<>();

        byDifferentCopiesDiscountList.add(new BooksSetDiscount(2, 7));
        byDifferentCopiesDiscountList.add(new BooksSetDiscount(3, 14));
        byDifferentCopiesDiscountList.add(new BooksSetDiscount(4, 28));
        byDifferentCopiesDiscountList.add(new BooksSetDiscount(5, 35));

        BookShopTest = new BookShopTest(byDifferentCopiesDiscountList);
    }

    @Test
    public void extract_one_set_of_4_books_when_cart_items_are_one_copy_for_first_four_books() {
        assertThat(booksSets.size(), is(1));
        assertThat(booksSets.get(0).getBooks().size(), is(4));
    }
}