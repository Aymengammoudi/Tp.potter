package books;

public class BookShop {

    private final String name;
    private int price;

    /**
     * Constructor of the class Book shop
     * 
     * @param name name of the book shop
     */
    public BookShop(String name) {
        this.name = name;
    }

    public HashSet<BookShop> getBooks() {
        return BookShop;
    }

    public int getPrice() {
        return price;
    }

    /**
     * method to compute the cost of a basket
     * 
     * @param books array corresponding to the number of each harry potter book the
     *              client desire to buy (books.length should return 5)
     * @return the cost in euro with the discount
     */
    public double cost(int[] books) {
        List<BooksSet> setsOfDifferentBooks = booksSetFactory.getDifferentBooksSetsWithMaxTotalDiscount(books);

        double totalPrice = 0.0;
        double setPrice = 0.0;

        for (BooksSet booksSet : setsOfDifferentBooks) {
            for (Book book : booksSet.getBooks()) {
                setPrice += this.getPrice();
            }

            setPrice = setPrice * (1.0 - (booksSet.getDiscount() / 100.0));
            totalPrice += setPrice;
            setPrice = 0;
        }

        return totalPrice;
    }
}
